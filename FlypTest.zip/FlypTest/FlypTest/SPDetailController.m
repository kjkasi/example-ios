//
//  SPDetailController.m
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPDetailController.h"
#import "SPMyFeedbackCell.h"



@interface SPDetailController () <UITableViewDataSource>

@property (strong, nonatomic) NSMutableArray *feedbackArray;
//@property (strong, nonatomic) NSMutableArray *reviewArray;

@end

@implementation SPDetailController

- (void)setBusiness:(SPBusiness *)business {
    
    _business = business;
    
    self.feedbackArray =
    [NSMutableArray arrayWithArray:[self.business.feedback allObjects]];
    

}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    for (UIView *view in self.collectionView) {
        
        //
        view.backgroundColor = [UIColor colorWithPatternImage: [UIImage imageNamed:@"background_tile"]];
        
    }
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    
    self.labelName.text = self.business.name;
    
    self.labelAddress.text = self.business.address;
    
    self.labelPhone.text = self.business.phone;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)segment:(UISegmentedControl *)sender {
    
    NSInteger index = sender.selectedSegmentIndex;

    
    [self.view bringSubviewToFront:[self.collectionView objectAtIndex:index]];
    
}

#pragma mark - Action

- (IBAction)buttonMap:(UIButton *)sender {
    
    [self performSegueWithIdentifier:@"SPMapSegue" sender:self.labelAddress.text];
    
}

- (IBAction)buttonPhone:(UIButton *)sender {
    
}

#pragma mark - UITableViewDataSource

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (tableView.tag == 100) {
        
        //return @"FEEDBACK FROM OTHER USERS";
        
    }
    return @"";
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SPFeedback *feedback = [self.feedbackArray objectAtIndex:indexPath.row];
    
    CGFloat height = [SPMyFeedbackCell heightForText:feedback.post];
    
    //NSLog(@"height %3.f", height);
    
    return 103.f + height - 21;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (tableView.tag == 100) {
        
        return [self.feedbackArray count];
        
    }
    
    return 0;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView.tag == 100) {
    
        static NSString *cellIdentifier = @"SPMyFeedbackCell";
        
        SPMyFeedbackCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        SPFeedback *feedback = [self.feedbackArray objectAtIndex:indexPath.row];
        
        SPUser *user = feedback.user;
        
        cell.labelPost.text = feedback.post;
        
        cell.labelName.text = [NSString stringWithFormat:@"%@ %@", user.firstName, user.lastName];
        
        //NSLog(@"photo path %@", user.photo);
        
        cell.imageUser.image = [UIImage imageWithContentsOfFile:user.photo];
        
        
    
        return cell;
    }
    
    return nil;
    
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg-cell.png"]];
    
    cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg-cell-selected.png"]];
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    [segue.destinationViewController setAddress:sender];
}

@end
