//
//  SPBusiness.m
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPBusiness.h"
#import "SPFeedback.h"
#import "SPReview.h"
#import "SPUser.h"


@implementation SPBusiness

@dynamic address;
@dynamic email;
@dynamic name;
@dynamic phone;
@dynamic type;
@dynamic website;
@dynamic users;
@dynamic feedback;
@dynamic review;

@end
