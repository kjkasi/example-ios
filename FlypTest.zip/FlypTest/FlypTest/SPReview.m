//
//  SPReview.m
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPReview.h"
#import "SPBusiness.h"
#import "SPUser.h"


@implementation SPReview

@dynamic post;
@dynamic business;
@dynamic user;

@end
