//
//  SPLibrary.m
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPLibrary.h"
#import "SPUser.h"
#import "SPBusiness.h"
#import "SPFeedback.h"

@implementation SPLibrary

- (void) genarateContent {
    
    ///////////////////
    //generate SPUser//
    ///////////////////
    
    NSString *photoPath = nil;
    
    SPUser *userOne = [SPUser MR_createEntity];
    userOne.firstName = @"Martin";
    userOne.lastName = @"Freeman";
    photoPath =
    [[NSBundle mainBundle] pathForResource:@"test-photo1.png" ofType:nil];
    userOne.photo = photoPath;
    
    
    SPUser *userTwo = [SPUser MR_createEntity];
    userTwo.firstName = @"Ian";
    userTwo.lastName = @"McKellen";
    photoPath =
    [[NSBundle mainBundle] pathForResource:@"test-photo2.png" ofType:nil];
    userTwo.photo = photoPath;
    
    SPUser *userTree = [SPUser MR_createEntity];
    userTree.firstName = @"Richard";
    userTree.lastName = @"Armitage";
    photoPath =
    [[NSBundle mainBundle] pathForResource:@"test-photo3.png" ofType:nil];
    userTree.photo = photoPath;
    
    SPUser *userFour = [SPUser MR_createEntity];
    userFour.firstName = @"James";
    userFour.lastName = @"Nesbitt";
    photoPath =
    [[NSBundle mainBundle] pathForResource:@"test-photo4.png" ofType:nil];
    userFour.photo = photoPath;
    
    ///////////////////////
    //generate SPBusiness//
    ///////////////////////
    
    SPBusiness *businessOne = [SPBusiness MR_createEntity];
    businessOne.name = @"Beer In Orange County";
    businessOne.type = @"(Service)";
    businessOne.phone = @"(949) 292-0544";
    businessOne.email = @"info@beerinorangecounty.com";
    businessOne.website = @"http://www.beerinorangecounty.com";
    businessOne.address = @"34270 Pacific Coast Hwy, Dana Point, CA";
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveOnlySelfAndWait];
    
    
    SPBusiness *businessTwo = [SPBusiness MR_createEntity];
    businessTwo.name = @"Saint Arnold Brewing Company";
    businessTwo.type = @"(Retail)";
    businessTwo.phone = @"(713) 686-9494";
    businessTwo.email = @"info@saintarnld.com";
    businessTwo.website = @"http://www.saintarnld.com";
    businessTwo.address = @"2000 Lyons Ave, Houston, TX";
    
    
    SPBusiness *businessTree = [SPBusiness MR_createEntity];
    businessTree.name = @"Cambridge Brewing Company";
    businessTree.type = @"(Dining)";
    businessTree.phone = @"(617) 494-1994";
    businessTree.email = @"info@cambridgebrewing.com";
    businessTree.website = @"http://www.cambridgebrewing.com";
    businessTree.address = @"1 Kendall Square, Building 100, Cambridge, MA";
    
    
    SPBusiness *businessFour = [SPBusiness MR_createEntity];
    businessFour.name = @"Founders Brewing Co";
    businessFour.type = @"(Dining)";
    businessFour.phone = @"(616) 776-1195";
    businessFour.email = @"info@microsoft.com";
    businessFour.website = @"http://foundersbrewing.com";
    businessFour.address = @"235 Crandville Ave SW, Grand Rapids, MI";
    
    SPBusiness *businessFive = [SPBusiness MR_createEntity];
    businessFive.name = @"Victory Brewing Co";
    businessFive.type = @"(Dining)";
    businessFive.phone = @"(610) 873-0881";
    businessFive.email = @"info@victorybeer.com";
    businessFive.website = @"http://www.victorybeer.com";
    businessFive.address = @"420 Acorn Ln, Downingtown, PA";
    
    
    
    /////////////////////
    //generate feedback//
    /////////////////////
    
    SPFeedback *feedbackOne = [SPFeedback MR_createEntity];
    feedbackOne.post = @"чо-каво, кстати?";
    
    SPFeedback *feedbaclTwo = [SPFeedback MR_createEntity];
    feedbaclTwo.post = @"me опять вернулся на irssi-xmpp и счастлив";
    
    SPFeedback *feedbaclTree = [SPFeedback MR_createEntity];
    feedbaclTree.post = @"игра этого вечера! http://theraccoonshare.com/GORILLAS.BAS/";
    
    SPFeedback *feedbaclFour = [SPFeedback MR_createEntity];
    feedbaclFour.post = @"хех, одна из сегодняшних тем шедевральна текстом, можно прямо на цитаты растаскивать. Вот пример - Most people don't even know what sysadmins do, but trust me, if they all took a lunch break at the same time they wouldn't make it to the deli before you ran out of bullets protecting your canned goods from roving bands of mutants.";
    
    SPFeedback *feedbaclFive = [SPFeedback MR_createEntity];
    feedbaclFive.post = @"или вот такой - The only reason coders' computers work better than non-coders' computers is coders know computers are schizophrenic little children with auto-immune diseases and we don't beat them when they're bad.";
    
    SPFeedback *feedbacSix = [SPFeedback MR_createEntity];
    feedbacSix.post = @"Сергей: это хорошо. Теперь тебя забанить раз 5 легче.";
    
    SPFeedback *feedbacSeven = [SPFeedback MR_createEntity];
    feedbacSeven.post = @"Сергей: ну а как еще нужно реагировать на твои высказывания?";
    
    SPFeedback *feedbaclEight = [SPFeedback MR_createEntity];
    feedbaclEight.post = @"Monory: ну варианта два. либо туда, либо в стенфорд. если конечно это твоя тематика.";
    
    SPFeedback *feedbaclNine = [SPFeedback MR_createEntity];
    feedbaclNine.post = @"Monory: там невероятное стечение обстоятельств. я до последнего не верил что нам это удастся. И состав преподавателей - прямо звездный.";
    
    
    
    
    //////////////////////////////////////////////////////////
    ////////////////////generate relationship/////////////////
    //////////////////////////////////////////////////////////
    
    ////////////
    //add like//
    ////////////
    
    [businessOne addUsers:[NSSet setWithObjects:
                           userOne,
                           userTwo,
                           userTree,
                           userFour, nil]];
    ////////////////
    //add feedback//
    ////////////////
    
    feedbackOne.user = userOne;
    feedbackOne.business = businessOne;
    
    feedbaclTwo.user = userOne;
    feedbaclTwo.business = businessOne;
    
    feedbaclTree.user = userTree;
    feedbaclTree.business = businessOne;
    
    feedbaclFour.user = userTwo;
    feedbaclFour.business = businessOne;
    
    feedbaclFive.user = userFour;
    feedbaclFive.business = businessOne;
    
    feedbacSix.user = userTree;
    feedbacSix.business = businessOne;
    
    feedbacSeven.user = userTree;
    feedbacSeven.business = businessOne;
    
    feedbaclEight.user = userFour;
    feedbaclEight.business = businessOne;
    
    feedbaclNine.user = userTwo;
    feedbaclNine.business = businessOne;
    
    

    
    
    ////////
    //save//
    ////////
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveOnlySelfAndWait];
    
}

@end
