//
//  SPMasterViewController.h
//  FlypTest
//
//  Created by Anton Minin on 29.04.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <CoreData/CoreData.h>

@interface SPMasterViewController : UITableViewController <NSFetchedResultsControllerDelegate>

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@end
