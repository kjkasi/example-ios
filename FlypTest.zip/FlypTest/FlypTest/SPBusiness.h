//
//  SPBusiness.h
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class SPFeedback, SPReview, SPUser;

@interface SPBusiness : NSManagedObject

@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSString * website;
@property (nonatomic, retain) NSSet *users;
@property (nonatomic, retain) NSSet *feedback;
@property (nonatomic, retain) NSSet *review;
@end

@interface SPBusiness (CoreDataGeneratedAccessors)

- (void)addUsersObject:(SPUser *)value;
- (void)removeUsersObject:(SPUser *)value;
- (void)addUsers:(NSSet *)values;
- (void)removeUsers:(NSSet *)values;

- (void)addFeedbackObject:(SPFeedback *)value;
- (void)removeFeedbackObject:(SPFeedback *)value;
- (void)addFeedback:(NSSet *)values;
- (void)removeFeedback:(NSSet *)values;

- (void)addReviewObject:(SPReview *)value;
- (void)removeReviewObject:(SPReview *)value;
- (void)addReview:(NSSet *)values;
- (void)removeReview:(NSSet *)values;

@end
