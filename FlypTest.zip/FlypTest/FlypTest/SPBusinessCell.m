//
//  SPBusinessCell.m
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPBusinessCell.h"

@implementation SPBusinessCell


+ (CGFloat) heightForText:(NSString*) text {
    
    
    UIFont* font = [UIFont systemFontOfSize:17.f];
    
    NSShadow* shadow = [[NSShadow alloc] init];
    shadow.shadowOffset = CGSizeMake(0, -1);
    shadow.shadowBlurRadius = 0.5;
    
    NSMutableParagraphStyle* paragraph = [[NSMutableParagraphStyle alloc] init];
    [paragraph setLineBreakMode:NSLineBreakByWordWrapping];
    [paragraph setAlignment:NSTextAlignmentLeft];
    
    NSDictionary* attributes =
    [NSDictionary dictionaryWithObjectsAndKeys:
     font, NSFontAttributeName,
     paragraph, NSParagraphStyleAttributeName,
     shadow, NSShadowAttributeName, nil];
    
    CGRect rect = [text boundingRectWithSize:CGSizeMake(267 , CGFLOAT_MAX)
                                     options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                  attributes:attributes
                                     context:nil];
    
    return CGRectGetHeight(rect);
}

+ (CGFloat) heightAttributedStringWith:(NSString*)name
                                  type:(NSString*)type
                               address:(NSString*)address{
    
    
    
    
    UITextView *textView = [[UITextView alloc] init];
    
    textView.attributedText = [SPBusinessCell getAttributedStringWith:name type:type address:address];
    
    CGSize size = [textView sizeThatFits:CGSizeMake(267, FLT_MAX)];
    
    return size.height;
}





+ (NSMutableAttributedString*) getAttributedStringWith:(NSString*)name
                                                  type:(NSString*)type
                                               address:(NSString*)address{
    

    NSString *string = [NSString stringWithFormat:@"%@ %@\n%@",name, type, address];
    
    NSRange rangeName = [string rangeOfString:name];
    NSRange rangeType = [string rangeOfString:type];
    NSRange rangeAddress = [string rangeOfString:address];
    
    NSDictionary *dictName = [self attrDictWithColor:[UIColor blackColor] size:17.f];
    NSDictionary *dictType = [self attrDictWithColor:[UIColor brownColor] size:17.f];
    NSDictionary *dictAddress = [self attrDictWithColor:[UIColor blackColor] size:11.f];
    
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:string];
    
    [attrString beginEditing];
    
    [attrString addAttributes:dictName range:rangeName];
    [attrString addAttributes:dictType range:rangeType];
    [attrString addAttributes:dictAddress range:rangeAddress];
    
    [attrString endEditing];
    
    
    return attrString;
}

+ (NSDictionary*) attrDictWithColor:(UIColor*)color size:(CGFloat)size {
    
    NSDictionary *attrDictionary = @{NSForegroundColorAttributeName: color, NSFontAttributeName: [UIFont systemFontOfSize:size]};
    
    return attrDictionary;
    
}

@end
