//
//  SPDetailController.h
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SPBusiness;

@interface SPDetailController : UIViewController

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *collectionView;

@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelAddress;
@property (weak, nonatomic) IBOutlet UILabel *labelPhone;

- (IBAction)buttonMap:(UIButton *)sender;
- (IBAction)buttonPhone:(UIButton *)sender;
- (IBAction)segment:(UISegmentedControl *)sender;

@property (strong, nonatomic) SPBusiness *business;

@end
