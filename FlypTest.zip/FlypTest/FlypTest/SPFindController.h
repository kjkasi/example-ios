//
//  SPFindController.h
//  FlypTest
//
//  Created by Anton Minin on 30.04.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPFindController : UITableViewController

@property (weak, nonatomic) IBOutlet UIButton *buttonFindNearby;
@property (weak, nonatomic) IBOutlet UIButton *buttonAsk;

- (IBAction)buttonAddBusiness:(UIButton *)sender;
- (IBAction)buttonAskFriends:(UIButton *)sender;

@end
