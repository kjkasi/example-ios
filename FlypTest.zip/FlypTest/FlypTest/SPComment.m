//
//  SPComment.m
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPComment.h"
#import "SPBusiness.h"
#import "SPUser.h"


@implementation SPComment

@dynamic post;
@dynamic business;
@dynamic users;

@end
