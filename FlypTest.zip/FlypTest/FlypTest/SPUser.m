//
//  SPUser.m
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPUser.h"
#import "SPBusiness.h"
#import "SPFeedback.h"
#import "SPReview.h"


@implementation SPUser

@dynamic firstName;
@dynamic lastName;
@dynamic photo;
@dynamic businesses;
@dynamic feedbacks;
@dynamic reviews;

@end
