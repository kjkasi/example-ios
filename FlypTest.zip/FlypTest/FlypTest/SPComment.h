//
//  SPComment.h
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class SPBusiness, SPUser;

@interface SPComment : NSManagedObject

@property (nonatomic, retain) NSString * post;
@property (nonatomic, retain) SPBusiness *business;
@property (nonatomic, retain) SPUser *users;

@end
