//
//  SPFeedback.m
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPFeedback.h"
#import "SPBusiness.h"
#import "SPUser.h"


@implementation SPFeedback

@dynamic post;
@dynamic business;
@dynamic user;

@end
