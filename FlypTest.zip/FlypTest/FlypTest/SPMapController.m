//
//  SPMapController.m
//  FlypTest
//
//  Created by Anton Minin on 03.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPMapController.h"
#import "MapKit/MapKit.h"

@interface SPMapController ()

@end

@implementation SPMapController


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)dealloc {
    
    self.address = nil;
    
}

-(void)viewWillAppear:(BOOL)animated {
    
    MKLocalSearchRequest *request = [[MKLocalSearchRequest alloc] init];
    
    request.naturalLanguageQuery = self.address;
    
    MKLocalSearch *search = [[MKLocalSearch alloc] initWithRequest:request];
    
    __weak SPMapController *weakSelf = self;
    
    [search startWithCompletionHandler:^(MKLocalSearchResponse *response, NSError *error) {
        
        //
        NSMutableArray *placemarks = [NSMutableArray array];
        
        for (MKMapItem *item in response.mapItems) {
            
            //
            [placemarks addObject:item.placemark];
            
        }
        
        //[self.viewMap removeAnnotation:[self.viewMap annotations]];
        
        [weakSelf.map showAnnotations:placemarks animated:YES];
        
    }];
    
}

- (void)viewDidAppear:(BOOL)animated {
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
