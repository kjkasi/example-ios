//
//  SPMapController.h
//  FlypTest
//
//  Created by Anton Minin on 03.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MKMapView;

@interface SPMapController : UIViewController

@property (strong, nonatomic) NSString *address;

@property (weak, nonatomic) IBOutlet MKMapView *map;

@end
