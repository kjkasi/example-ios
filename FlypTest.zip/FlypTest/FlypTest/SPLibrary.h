//
//  SPLibrary.h
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPLibrary : NSObject

- (void) genarateContent;

@end
