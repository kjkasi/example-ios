//
//  SPBusinessCell.h
//  FlypTest
//
//  Created by Anton Minin on 01.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPBusinessCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *labelText;

@property (weak, nonatomic) IBOutlet UILabel *labelLikeCount;
@property (weak, nonatomic) IBOutlet UILabel *labelMarkCount;

+ (CGFloat) heightForText:(NSString*) text;

+ (CGFloat) heightAttributedStringWith:(NSString*)name
                                  type:(NSString*)type
                               address:(NSString*)address;

+ (NSMutableAttributedString*) getAttributedStringWith:(NSString*)name
                                                  type:(NSString*)type
                                               address:(NSString*)address;

@end
