//
//  SPMyFeedbackCell.h
//  FlypTest
//
//  Created by Anton Minin on 03.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPMyFeedbackCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *labelPost;
@property (weak, nonatomic) IBOutlet UIImageView *imageUser;
@property (weak, nonatomic) IBOutlet UILabel *labelName;

+ (CGFloat) heightForText:(NSString*) text;

@end
