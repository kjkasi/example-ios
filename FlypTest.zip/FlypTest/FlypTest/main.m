//
//  main.m
//  FlypTest
//
//  Created by Anton Minin on 29.04.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SPAppDelegate class]));
    }
}
