//
//  SPUser.h
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class SPBusiness, SPFeedback, SPReview;

@interface SPUser : NSManagedObject

@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSString * photo;
@property (nonatomic, retain) NSSet *businesses;
@property (nonatomic, retain) NSSet *feedbacks;
@property (nonatomic, retain) SPReview *reviews;
@end

@interface SPUser (CoreDataGeneratedAccessors)

- (void)addBusinessesObject:(SPBusiness *)value;
- (void)removeBusinessesObject:(SPBusiness *)value;
- (void)addBusinesses:(NSSet *)values;
- (void)removeBusinesses:(NSSet *)values;

- (void)addFeedbacksObject:(SPFeedback *)value;
- (void)removeFeedbacksObject:(SPFeedback *)value;
- (void)addFeedbacks:(NSSet *)values;
- (void)removeFeedbacks:(NSSet *)values;

@end
