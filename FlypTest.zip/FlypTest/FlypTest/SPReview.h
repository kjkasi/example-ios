//
//  SPReview.h
//  FlypTest
//
//  Created by Anton Minin on 02.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class SPBusiness, SPUser;

@interface SPReview : NSManagedObject

@property (nonatomic, retain) NSString * post;
@property (nonatomic, retain) SPBusiness *business;
@property (nonatomic, retain) NSSet *user;
@end

@interface SPReview (CoreDataGeneratedAccessors)

- (void)addUserObject:(SPUser *)value;
- (void)removeUserObject:(SPUser *)value;
- (void)addUser:(NSSet *)values;
- (void)removeUser:(NSSet *)values;

@end
