//
//  SPMyFeedbackCell.m
//  FlypTest
//
//  Created by Anton Minin on 03.05.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPMyFeedbackCell.h"

@implementation SPMyFeedbackCell

+ (CGFloat) heightForText:(NSString*) text {
    
    UITextView *textView = [[UITextView alloc] init];
    
    textView.text = text;
    
    CGSize size = [textView sizeThatFits:CGSizeMake(195, FLT_MAX)];
    
    return size.height;
}


@end
