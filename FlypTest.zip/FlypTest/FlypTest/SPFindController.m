//
//  SPFindController.m
//  FlypTest
//
//  Created by Anton Minin on 30.04.14.
//  Copyright (c) 2014 Anton Minin. All rights reserved.
//

#import "SPFindController.h"
#import "SPBusiness.h"
#import "SPBusinessCell.h"

@interface SPFindController()

@property (strong, nonatomic) NSMutableArray* objectArray;

@end

@interface SPFindController ()

@end

@implementation SPFindController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.objectArray = [NSMutableArray arrayWithArray:[SPBusiness MR_findAll]];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage: [UIImage imageNamed:@"background_tile"]];
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SPBusiness* business = [self.objectArray objectAtIndex:indexPath.row];
    
    //NSString *text = [NSString stringWithFormat:@"%@ %@\n%@", business.name, business.type, business.address];
    
    CGFloat height = [SPBusinessCell heightAttributedStringWith:business.name type:business.type address:business.address];
    
    //NSLog(@"height %2.f", height);
    
    //height = 0;
    
    return 75.f + height - 17;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSUInteger rowCount = [[SPBusiness MR_numberOfEntities] unsignedIntegerValue];
    
    //NSLog(@"rowCount %d", rowCount);
    
    return rowCount;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"SPFindCell";
    
    
    /*
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
    }
    */
    
    SPBusinessCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    SPBusiness* business = [self.objectArray objectAtIndex:indexPath.row];
    
    cell.labelText.attributedText = [SPBusinessCell getAttributedStringWith:business.name type:business.type address:business.address];
    
    //cell.labelMarkCount.text = [NSString stringWithFormat:@"%2.f", CGRectGetHeight(cell.bounds)];
    
    NSUInteger likeCount = [business.users count];
    
    NSString *string = [NSString stringWithFormat:@"%lu", (unsigned long)likeCount];
    
    if (likeCount) {
        
        cell.labelLikeCount.text = string;
        
    } else {
        
        cell.labelLikeCount.text = @"";
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg-cell.png"]];
    
    cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg-cell-selected.png"]];

    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    
    [self performSegueWithIdentifier:@"SPDetailSegue"
                              sender:[self.objectArray objectAtIndex:indexPath.row]];
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    [segue.destinationViewController setBusiness:(SPBusiness*)sender];
}

- (IBAction)buttonAddBusiness:(UIButton *)sender {
}

- (IBAction)buttonAskFriends:(UIButton *)sender {
}
@end
